// ─────────────────────────────────────────────────────────────
//  True Full‑Page Uploader – v21.1
//  · Listens for icon click or keyboard shortcut.
//  · Frame 0 with fixed/sticky, hides them thereafter.
//  · Stitches frames using scrollY coordinates.
//  · Reuses existing AI Studio tab.
// ─────────────────────────────────────────────────────────────

// Injected: hide/show fixed & sticky elements
function hideFixedSticky() {
  const els = Array.from(document.querySelectorAll('*')).filter(el => {
    const pos = getComputedStyle(el).position;
    return pos === 'fixed' || pos === 'sticky';
  });
  window.__hiddenEls = els.map(el => {
    const old = el.style.visibility;
    el.style.visibility = 'hidden';
    return { el, old };
  });
}
function restoreFixedSticky() {
  (window.__hiddenEls || []).forEach(({ el, old }) => el.style.visibility = old);
  delete window.__hiddenEls;
}

// Main capture routine
async function captureUntilBottom(tab) {
  const tgt = { tabId: tab.id };
  // FIX: Increased THROTTLE to avoid exceeding Chrome's capture rate limit.
  // The original value of 220ms was too aggressive.
  const THROTTLE = 400; // ms
  const PAINT    = 120; // ms
  const SCROLL_OVERLAP = 150; // px

  const [{ result: { vpW, dpr } }] = await chrome.scripting.executeScript({
    target: tgt,
    func: () => ({ vpW: window.innerWidth, dpr: window.devicePixelRatio })
  });

  await chrome.scripting.executeScript({ target: tgt, func: () => window.scrollTo(0, 0) });
  await new Promise(r => setTimeout(r, PAINT));

  const frames = [];
  const firstSliceUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
  frames.push({ url: firstSliceUrl, y: 0 });
  await new Promise(r => setTimeout(r, THROTTLE));

  await chrome.scripting.executeScript({ target: tgt, func: hideFixedSticky });

  let prevY = 0;
  while (true) {
    await chrome.scripting.executeScript({
      target: tgt,
      func: (overlap) => {
        const scrollAmount = window.innerHeight - overlap;
        const scrollByY = scrollAmount > 0 ? scrollAmount : window.innerHeight * 0.8;
        window.scrollBy(0, scrollByY);
      },
      args: [SCROLL_OVERLAP]
    });
    await new Promise(r => setTimeout(r, PAINT));

    const [{ result: currY }] = await chrome.scripting.executeScript({ target: tgt, func: () => window.scrollY });

    if (currY === prevY) break;
    
    const sliceUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
    frames.push({ url: sliceUrl, y: currY });
    await new Promise(r => setTimeout(r, THROTTLE));
    prevY = currY;
  }

  const [{ result: finalUrl }] = await chrome.scripting.executeScript({
    target: tgt,
    func: async ({ frames, w, dpr }) => {
      const bitmaps = await Promise.all(
        frames.map(async frame => createImageBitmap(await (await fetch(frame.url)).blob()))
      );
      const lastFrame = frames[frames.length - 1];
      const lastBitmap = bitmaps[bitmaps.length - 1];
      const totalH = (lastFrame.y * dpr) + lastBitmap.height;
      const canvas = new OffscreenCanvas(w * dpr, totalH);
      const ctx = canvas.getContext('2d');
      bitmaps.forEach((bmp, i) => ctx.drawImage(bmp, 0, frames[i].y * dpr));
      const blobOut = await canvas.convertToBlob({ type: 'image/png' });
      return new Promise(res => {
        const fr = new FileReader();
        fr.onload = () => res(fr.result);
        fr.readAsDataURL(blobOut);
      });
    },
    args: [{ frames, w: vpW, dpr }]
  });

  await chrome.scripting.executeScript({ target: tgt, func: restoreFixedSticky });
  await chrome.scripting.executeScript({ target: tgt, func: () => window.scrollTo(0, 0) });

  return finalUrl;
}

// Injected into AI Studio to perform the upload
function simulateFileDrop(dataUrl) {
  const sel = 'ms-prompt-input-wrapper';
  let tries = 0;
  const iv = setInterval(() => {
    const dz = document.querySelector(sel);
    if (dz) {
      clearInterval(iv);
      fetch(dataUrl).then(r => r.blob()).then(blob => {
        const file = new File([blob], 'screenshot.png', { type: 'image/png' });
        const dt = new DataTransfer();
        dt.items.add(file);
        const ev = new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: dt });
        dz.dispatchEvent(ev);
      });
    } else if (++tries > 30) {
      clearInterval(iv);
      console.error(`Drop-zone (${sel}) not found.`);
    }
  }, 500);
}

// Handles finding or creating an AI Studio tab and sending the image
async function sendToAIStudio(dataUrl) {
  const aiStudioUrl = "*://aistudio.google.com/*";
  const tabs = await chrome.tabs.query({ url: aiStudioUrl });

  if (tabs.length > 0) {
    console.log("Found existing AI Studio tab. Reusing it.");
    const targetTab = tabs[0];
    await chrome.windows.update(targetTab.windowId, { focused: true });
    await chrome.tabs.update(targetTab.id, { active: true });
    await chrome.scripting.executeScript({
      target: { tabId: targetTab.id },
      function: simulateFileDrop,
      args: [dataUrl]
    });
  } else {
    console.log("No AI Studio tab found. Creating a new one.");
    const newTab = await chrome.tabs.create({ url: 'https://aistudio.google.com/prompts/new_chat' });
    const listener = (tabId, changeInfo) => {
      if (tabId === newTab.id && changeInfo.status === 'complete') {
        chrome.scripting.executeScript({
          target: { tabId: newTab.id },
          function: simulateFileDrop,
          args: [dataUrl]
        });
        chrome.tabs.onUpdated.removeListener(listener);
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  }
}

// Main trigger function
async function startCaptureProcess(tab) {
  if (!tab || !tab.id) {
    console.error("Cannot start capture: target tab is invalid.");
    return;
  }
  try {
    const dataUrl = await captureUntilBottom(tab);
    await sendToAIStudio(dataUrl);
  } catch (e) {
    console.error('Capture failed:', e);
  }
}

// Add listeners for the two trigger methods
chrome.action.onClicked.addListener(startCaptureProcess);

chrome.commands.onCommand.addListener((command, tab) => {
  // This log will help us debug.
  console.log(`Command received: "${command}" on tab ${tab.id}`);
  if (command === "_execute_action") {
    startCaptureProcess(tab);
  }
});