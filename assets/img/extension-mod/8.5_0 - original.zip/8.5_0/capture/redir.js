window.location = `../capture.html${window.location.search}${window.location.hash}`;
