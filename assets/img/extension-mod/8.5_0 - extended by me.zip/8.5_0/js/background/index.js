// background.js - Central coordinator for extension actions

// On first install, open a welcome tab
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === "install") {
        const welcomeUrl = chrome.runtime.getURL("/welcome.html");
        chrome.tabs.create({ url: welcomeUrl });
    }
});

// Listen for the keyboard shortcut command

chrome.commands.onCommand.addListener(async (command) => {
    if (command === "send-to-aistudio-shortcut") {
        console.log("Keyboard shortcut triggered.");
        try {
            const [currentTab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (currentTab) {
                const dataUrl = await chrome.tabs.captureVisibleTab(currentTab.windowId, { format: "png" });
                await sendToAIStudio(dataUrl);
            } else {
                console.error("No active tab found to capture.");
            }
        } catch (err) {
            console.error("Error capturing visible tab:", err);
        }
    }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "sendToAIStudio") {
        sendToAIStudio(message.dataUrl)
            .then(() => sendResponse({ status: "success" }))
            .catch(err => {
                console.error("Error in background handling:", err);
                sendResponse({ status: "error", message: err.message });
            });
        return true; // Indicates we will respond asynchronously
    }
});

// This function will be INJECTED into the AI Studio page.
// It runs in the content script context of that page.
function simulateFileDrop(dataUrl) {
    // Helper function to convert a data URL to a Blob object
    function dataURLtoBlob(dataurl) {
        try {
            let arr = dataurl.split(','),
                mime = arr[0].match(/:(.*?);/)[1],
                bstr = atob(arr[1]),
                n = bstr.length,
                u8arr = new Uint8Array(n);
            while (n--) {
                u8arr[n] = bstr.charCodeAt(n);
            }
            return new Blob([u8arr], { type: mime });
        } catch (e) {
            console.error("Error in dataURLtoBlob:", e);
            return null;
        }
    }

    const sel = 'ms-prompt-input-wrapper'; // The drop zone selector
    let tries = 0;
    const interval = setInterval(() => {
        const dropZone = document.querySelector(sel);
        if (dropZone) {
            clearInterval(interval);
            console.log("AI Studio drop zone found. Creating and dispatching drop event.");

            const blob = dataURLtoBlob(dataUrl);
            if (!blob) {
                console.error("Failed to convert data URL to blob.");
                return;
            }

            const file = new File([blob], 'screenshot.png', { type: 'image/png' });
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(file);
            const dropEvent = new DragEvent('drop', {
                bubbles: true,
                cancelable: true,
                dataTransfer: dataTransfer
            });
            dropZone.dispatchEvent(dropEvent);
            console.log("Drop event dispatched.");

        } else if (++tries > 40) { // Increased wait time
            clearInterval(interval);
            console.error(`Drop-zone ('${sel}') not found on AI Studio page.`);
        }
    }, 500);
}


// Main function to handle the tab management and script injection
async function sendToAIStudio(dataUrl) {
    const aiStudioUrl = "*://aistudio.google.com/*";

    const tabs = await chrome.tabs.query({ url: aiStudioUrl });

    if (tabs.length > 0) {
        console.log("Found existing AI Studio tab. Reusing it.");
        const targetTab = tabs[0];
        await chrome.windows.update(targetTab.windowId, { focused: true });
        await chrome.tabs.update(targetTab.id, { active: true });
        
        // Wait for tab to be fully loaded before injecting script
        if (targetTab.status !== "complete") {
            await new Promise(resolve => {
                const listener = (tabId, changeInfo) => {
                    if (tabId === targetTab.id && changeInfo.status === 'complete') {
                        chrome.tabs.onUpdated.removeListener(listener);
                        resolve();
                    }
                };
                chrome.tabs.onUpdated.addListener(listener);
            });
        }
        
        await chrome.scripting.executeScript({
            target: { tabId: targetTab.id },
            function: simulateFileDrop,
            args: [dataUrl]
        });

    } else {
        console.log("No AI Studio tab found. Creating a new one.");
        const newTab = await chrome.tabs.create({ url: 'https://aistudio.google.com/prompts/new_chat', active: true });
        
        const listener = async (tabId, changeInfo) => {
          if (tabId === newTab.id && changeInfo.status === 'complete') {
            await chrome.scripting.executeScript({
              target: { tabId: newTab.id },
              function: simulateFileDrop,
              args: [dataUrl]
            });
            chrome.tabs.onUpdated.removeListener(listener);
          }
        };
        chrome.tabs.onUpdated.addListener(listener);
    }
}

//# sourceMappingURL=index.js.map